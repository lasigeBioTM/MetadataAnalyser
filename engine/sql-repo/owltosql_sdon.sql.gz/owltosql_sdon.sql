-- phpMyAdmin SQL Dump
-- version 4.0.10.12
-- http://www.phpmyadmin.net
--
-- Host: 127.3.70.2:3306
-- Generation Time: Mar 20, 2016 at 12:34 PM
-- Server version: 5.5.45
-- PHP Version: 5.3.3

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `owltosql_sdon`
--
CREATE DATABASE IF NOT EXISTS `owltosql_sdon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `owltosql_sdon`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `sp_conceptspec`$$
CREATE DEFINER=`admintIR128q`@`127.3.70.2` PROCEDURE `sp_conceptspec`(IN concept_iri VARCHAR(100), OUT spec_value NUMERIC(6, 4))
    READS SQL DATA
BEGIN
   /**/
   -- DECLARE spec_value                         NUMERIC(6, 4);
   DECLARE start_time, end_time               BIGINT;
   -- DECLARE aux         VARCHAR(200);
   --
   DECLARE owl_obj_id                         INTEGER DEFAULT 0;
   DECLARE concept_ancestors_count            INTEGER DEFAULT 0;
   DECLARE leaf_descendents_count             INTEGER DEFAULT 0;
   DECLARE leaf_descendents_ancestors_count   INTEGER DEFAULT 0;
   DECLARE leaf_ancestors_count               INTEGER DEFAULT 0;
   DECLARE leaft_concept_delta_sum            INTEGER DEFAULT 0;

   -- Declare _val variables to read in each record from the cursor
   DECLARE subclass_val                       INTEGER;
   DECLARE name_val                           TEXT;
   DECLARE distance_val                       INTEGER;

   --
   DECLARE no_more_rows                       BOOLEAN DEFAULT FALSE;
   DECLARE loop_cntr                          INTEGER DEFAULT 0;

   DECLARE
      leaf_descendents_cursor CURSOR FOR   SELECT h.subclass,
                                                  n.name,
                                                  h.distance
                                             FROM owltosql_sdon.hierarchy h
                                                  INNER JOIN
                                                  owltosql_sdon.owl_objects o
                                                     ON h.subclass = o.id
                                                  INNER JOIN owltosql_sdon.names n
                                                     ON h.subclass = n.id
                                                  INNER JOIN owltosql_sdon.leaves l
                                                     ON h.subclass = l.id
                                            WHERE     o.type = 'Class'
                                                  AND h.superclass =
                                                         (SELECT w.id
                                                            FROM owltosql_sdon.owl_objects
                                                                 w
                                                           WHERE     w.type =
                                                                        'Class'
                                                                 AND LOWER(
                                                                        w.iri) =
                                                                        LOWER(
                                                                           concept_iri))
                                                  AND h.superclass <>
                                                         h.subclass
                                         ORDER BY h.distance ASC, h.subclass;

   -- declare handlers for exceptions
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_rows = TRUE;

   -- read the starting time, in miliseconds
   SET start_time = UNIX_TIMESTAMP();

   -- get owl object id for the given concept iri
   SELECT owltosql_sdon.f_get_owlid_from_iri(concept_iri)
     INTO owl_obj_id;

   -- check for a valid owl object
   IF owl_obj_id > 0
   THEN
      -- get all ancestors count for the given concept
      SELECT owltosql_sdon.f_concept_ancestors_count(owl_obj_id)
        INTO concept_ancestors_count;

      -- check for worst case scenario, concept is a top ontology node
      IF concept_ancestors_count > 0
      THEN
         -- get leaf descendents average calculus
         OPEN leaf_descendents_cursor;

         SELECT FOUND_ROWS()
           INTO leaf_descendents_count;

         -- check for best case scenario, concept is a leaf ontology node
         IF leaf_descendents_count > 0
         THEN
            SET leaft_concept_delta_sum = 0;                 -- SET aux = 'S';

           leaf_loop:
            LOOP
               FETCH leaf_descendents_cursor
                  INTO subclass_val, name_val, distance_val;

               -- break loop condition
               IF no_more_rows
               THEN
                  CLOSE leaf_descendents_cursor;

                  LEAVE leaf_loop;
               END IF;

               -- get ancestors count for this leaf subclass concept
               SELECT owltosql_sdon.f_concept_ancestors_count(subclass_val)
                 INTO leaf_ancestors_count;

               -- calculate leaf to concept delta distance
               SET leaft_concept_delta_sum =
                        leaft_concept_delta_sum
                      + (leaf_ancestors_count - concept_ancestors_count);

               -- SET aux = CONCAT(aux, ';', (leaf_ancestors_count - concept_ancestors_count));

               -- print out statement
               -- SELECT subclass_val, name_val, distance_val;


               -- count the number of times looped
               SET loop_cntr = loop_cntr + 1;
            END LOOP leaf_loop;

            IF leaft_concept_delta_sum > 0
            THEN
               -- calcule specification metric for the given concept
               SET spec_value =
                      (  concept_ancestors_count
                       / (  concept_ancestors_count
                          + (leaft_concept_delta_sum / loop_cntr)));
            ELSE
               -- something went wrong in delta calculus
               SET spec_value = 0;

               -- SELECT spec_value;
            END IF;

            --
            SET end_time = UNIX_TIMESTAMP();

            -- SELECT aux;
            /* SELECT concept_ancestors_count,
                   loop_cntr AS 'leaf_descendents_sum',
                   leaft_concept_delta_sum,
                   loop_cntr,
                   spec_value,
                   (leaft_concept_delta_sum / loop_cntr),
                   start_time,
                   end_time,
                   end_time - start_time; */
         ELSE
            CLOSE leaf_descendents_cursor;

            -- this is a leaf concept, set the highest spec value
            SET spec_value = 1;

            -- SELECT spec_value;
         END IF;
      ELSE
         -- this is a top concept in the ontology hierarchy
         SET spec_value = 0;

         -- SELECT spec_value;
      END IF;
   ELSE
      -- this is not a valid concept, set the least spec value
      SET spec_value = -1;

      -- SELECT spec_value;
   END IF;
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `f_concept_ancestors_count`$$
CREATE DEFINER=`admintIR128q`@`127.3.70.2` FUNCTION `f_concept_ancestors_count`(owl_obj_id INTEGER(10)) RETURNS int(11)
BEGIN
   DECLARE result_value   INTEGER DEFAULT 0;

     -- get all ancestors count for the given concept
     SELECT count(h.superclass) hopcount
       INTO result_value
       FROM owltosql_sdon.hierarchy h
            INNER JOIN owltosql_sdon.owl_objects o ON h.superclass = o.id
            INNER JOIN owltosql_sdon.names n ON h.superclass = n.id
      WHERE     h.subclass = owl_obj_id
            AND h.superclass <> owl_obj_id
            AND o.type = 'Class'
   ORDER BY h.distance DESC, h.superclass;

   RETURN (result_value);
END$$

DROP FUNCTION IF EXISTS `f_get_owlid_from_iri`$$
CREATE DEFINER=`admintIR128q`@`127.3.70.2` FUNCTION `f_get_owlid_from_iri`(concept_iri VARCHAR(100)) RETURNS int(11)
BEGIN
   DECLARE result_value   INTEGER DEFAULT 0;

   SELECT o.id
     INTO result_value
     FROM owltosql_sdon.owl_objects o
    WHERE o.type = 'Class' AND LOWER(o.iri) = LOWER(concept_iri);

   RETURN result_value;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `extras`
--

DROP TABLE IF EXISTS `extras`;
CREATE TABLE IF NOT EXISTS `extras` (
  `tag` varchar(256) NOT NULL,
  `value` text,
  UNIQUE KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hierarchy`
--

DROP TABLE IF EXISTS `hierarchy`;
CREATE TABLE IF NOT EXISTS `hierarchy` (
  `subclass` int(11) NOT NULL,
  `superclass` int(11) NOT NULL,
  `distance` int(11) NOT NULL,
  UNIQUE KEY `subclass_2` (`subclass`,`superclass`),
  KEY `subclass` (`subclass`),
  KEY `superclass` (`superclass`),
  KEY `distance` (`distance`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hierarchy`
--

INSERT INTO `hierarchy` (`subclass`, `superclass`, `distance`) VALUES
(1, 1, 0),
(2, 2, 0),
(3, 3, 0),
(5, 5, 0),
(6, 6, 0),
(7, 7, 0),
(8, 8, 0),
(9, 9, 0),
(10, 10, 0),
(12, 12, 0),
(13, 13, 0),
(14, 14, 0),
(15, 15, 0),
(16, 16, 0),
(17, 17, 0),
(19, 19, 0),
(20, 20, 0),
(21, 21, 0),
(22, 22, 0),
(23, 23, 0),
(24, 24, 0),
(25, 25, 0),
(26, 26, 0),
(27, 27, 0),
(28, 28, 0),
(29, 29, 0),
(30, 30, 0),
(31, 31, 0),
(32, 32, 0),
(33, 33, 0),
(34, 34, 0),
(35, 35, 0),
(36, 36, 0),
(37, 37, 0),
(39, 39, 0),
(40, 40, 0),
(42, 42, 0),
(43, 43, 0),
(45, 45, 0),
(47, 47, 0),
(48, 48, 0),
(49, 49, 0),
(50, 50, 0),
(51, 51, 0),
(52, 52, 0),
(53, 53, 0),
(54, 54, 0),
(56, 56, 0),
(57, 57, 0),
(58, 58, 0),
(59, 59, 0),
(60, 60, 0),
(61, 61, 0),
(63, 63, 0),
(64, 64, 0),
(65, 65, 0),
(67, 67, 0),
(68, 68, 0),
(69, 69, 0),
(70, 70, 0),
(71, 71, 0),
(72, 72, 0),
(73, 73, 0),
(74, 74, 0),
(1, 47, 1),
(3, 34, 1),
(5, 15, 1),
(6, 36, 1),
(7, 65, 1),
(8, 24, 1),
(9, 14, 1),
(10, 15, 1),
(12, 47, 1),
(13, 24, 1),
(14, 71, 1),
(15, 24, 1),
(16, 21, 1),
(17, 24, 1),
(19, 16, 1),
(20, 37, 1),
(21, 42, 1),
(22, 5, 1),
(23, 17, 1),
(24, 65, 1),
(25, 37, 1),
(26, 7, 1),
(27, 20, 1),
(28, 34, 1),
(29, 7, 1),
(30, 5, 1),
(31, 32, 1),
(32, 7, 1),
(33, 14, 1),
(34, 71, 1),
(35, 29, 1),
(36, 8, 1),
(37, 13, 1),
(39, 14, 1),
(40, 29, 1),
(42, 60, 1),
(43, 32, 1),
(45, 60, 1),
(47, 24, 1),
(48, 14, 1),
(49, 24, 1),
(50, 73, 1),
(51, 37, 1),
(52, 29, 1),
(53, 29, 1),
(54, 5, 1),
(56, 32, 1),
(57, 29, 1),
(58, 49, 1),
(59, 29, 1),
(60, 2, 1),
(61, 5, 1),
(63, 26, 1),
(64, 26, 1),
(65, 42, 1),
(67, 37, 1),
(68, 29, 1),
(69, 5, 1),
(70, 5, 1),
(71, 45, 1),
(72, 26, 1),
(73, 13, 1),
(74, 5, 1),
(1, 24, 2),
(3, 71, 2),
(5, 24, 2),
(6, 8, 2),
(7, 42, 2),
(8, 65, 2),
(9, 71, 2),
(10, 24, 2),
(12, 24, 2),
(13, 65, 2),
(14, 45, 2),
(15, 65, 2),
(16, 42, 2),
(17, 65, 2),
(19, 21, 2),
(20, 13, 2),
(21, 60, 2),
(22, 15, 2),
(23, 24, 2),
(24, 42, 2),
(25, 13, 2),
(26, 65, 2),
(27, 37, 2),
(28, 71, 2),
(29, 65, 2),
(30, 15, 2),
(31, 7, 2),
(32, 65, 2),
(33, 71, 2),
(34, 45, 2),
(35, 7, 2),
(36, 24, 2),
(37, 24, 2),
(39, 71, 2),
(40, 7, 2),
(42, 2, 2),
(43, 7, 2),
(45, 2, 2),
(47, 65, 2),
(48, 71, 2),
(49, 65, 2),
(50, 13, 2),
(51, 13, 2),
(52, 7, 2),
(53, 7, 2),
(54, 15, 2),
(56, 7, 2),
(57, 7, 2),
(58, 24, 2),
(59, 7, 2),
(61, 15, 2),
(63, 7, 2),
(64, 7, 2),
(65, 60, 2),
(67, 13, 2),
(68, 7, 2),
(69, 15, 2),
(70, 15, 2),
(71, 60, 2),
(72, 7, 2),
(73, 24, 2),
(74, 15, 2),
(1, 65, 3),
(3, 45, 3),
(5, 65, 3),
(6, 24, 3),
(7, 60, 3),
(8, 42, 3),
(9, 45, 3),
(10, 65, 3),
(12, 65, 3),
(13, 42, 3),
(14, 60, 3),
(15, 42, 3),
(16, 60, 3),
(17, 42, 3),
(19, 42, 3),
(20, 24, 3),
(21, 2, 3),
(22, 24, 3),
(23, 65, 3),
(24, 60, 3),
(25, 24, 3),
(26, 42, 3),
(27, 13, 3),
(28, 45, 3),
(29, 42, 3),
(30, 24, 3),
(31, 65, 3),
(32, 42, 3),
(33, 45, 3),
(34, 60, 3),
(35, 65, 3),
(36, 65, 3),
(37, 65, 3),
(39, 45, 3),
(40, 65, 3),
(43, 65, 3),
(47, 42, 3),
(48, 45, 3),
(49, 42, 3),
(50, 24, 3),
(51, 24, 3),
(52, 65, 3),
(53, 65, 3),
(54, 24, 3),
(56, 65, 3),
(57, 65, 3),
(58, 65, 3),
(59, 65, 3),
(61, 24, 3),
(63, 65, 3),
(64, 65, 3),
(65, 2, 3),
(67, 24, 3),
(68, 65, 3),
(69, 24, 3),
(70, 24, 3),
(71, 2, 3),
(72, 65, 3),
(73, 65, 3),
(74, 24, 3),
(1, 42, 4),
(3, 60, 4),
(5, 42, 4),
(6, 65, 4),
(7, 2, 4),
(8, 60, 4),
(9, 60, 4),
(10, 42, 4),
(12, 42, 4),
(13, 60, 4),
(14, 2, 4),
(15, 60, 4),
(16, 2, 4),
(17, 60, 4),
(19, 60, 4),
(20, 65, 4),
(22, 65, 4),
(23, 42, 4),
(24, 2, 4),
(25, 65, 4),
(26, 60, 4),
(27, 24, 4),
(28, 60, 4),
(29, 60, 4),
(30, 65, 4),
(31, 42, 4),
(32, 60, 4),
(33, 60, 4),
(34, 2, 4),
(35, 42, 4),
(36, 42, 4),
(37, 42, 4),
(39, 60, 4),
(40, 42, 4),
(43, 42, 4),
(47, 60, 4),
(48, 60, 4),
(49, 60, 4),
(50, 65, 4),
(51, 65, 4),
(52, 42, 4),
(53, 42, 4),
(54, 65, 4),
(56, 42, 4),
(57, 42, 4),
(58, 42, 4),
(59, 42, 4),
(61, 65, 4),
(63, 42, 4),
(64, 42, 4),
(67, 65, 4),
(68, 42, 4),
(69, 65, 4),
(70, 65, 4),
(72, 42, 4),
(73, 42, 4),
(74, 65, 4),
(1, 60, 5),
(3, 2, 5),
(5, 60, 5),
(6, 42, 5),
(8, 2, 5),
(9, 2, 5),
(10, 60, 5),
(12, 60, 5),
(13, 2, 5),
(15, 2, 5),
(17, 2, 5),
(19, 2, 5),
(20, 42, 5),
(22, 42, 5),
(23, 60, 5),
(25, 42, 5),
(26, 2, 5),
(27, 65, 5),
(28, 2, 5),
(29, 2, 5),
(30, 42, 5),
(31, 60, 5),
(32, 2, 5),
(33, 2, 5),
(35, 60, 5),
(36, 60, 5),
(37, 60, 5),
(39, 2, 5),
(40, 60, 5),
(43, 60, 5),
(47, 2, 5),
(48, 2, 5),
(49, 2, 5),
(50, 42, 5),
(51, 42, 5),
(52, 60, 5),
(53, 60, 5),
(54, 42, 5),
(56, 60, 5),
(57, 60, 5),
(58, 60, 5),
(59, 60, 5),
(61, 42, 5),
(63, 60, 5),
(64, 60, 5),
(67, 42, 5),
(68, 60, 5),
(69, 42, 5),
(70, 42, 5),
(72, 60, 5),
(73, 60, 5),
(74, 42, 5),
(1, 2, 6),
(5, 2, 6),
(6, 60, 6),
(10, 2, 6),
(12, 2, 6),
(20, 60, 6),
(22, 60, 6),
(23, 2, 6),
(25, 60, 6),
(27, 42, 6),
(30, 60, 6),
(31, 2, 6),
(35, 2, 6),
(36, 2, 6),
(37, 2, 6),
(40, 2, 6),
(43, 2, 6),
(50, 60, 6),
(51, 60, 6),
(52, 2, 6),
(53, 2, 6),
(54, 60, 6),
(56, 2, 6),
(57, 2, 6),
(58, 2, 6),
(59, 2, 6),
(61, 60, 6),
(63, 2, 6),
(64, 2, 6),
(67, 60, 6),
(68, 2, 6),
(69, 60, 6),
(70, 60, 6),
(72, 2, 6),
(73, 2, 6),
(74, 60, 6),
(6, 2, 7),
(20, 2, 7),
(22, 2, 7),
(25, 2, 7),
(27, 60, 7),
(30, 2, 7),
(50, 2, 7),
(51, 2, 7),
(54, 2, 7),
(61, 2, 7),
(67, 2, 7),
(69, 2, 7),
(70, 2, 7),
(74, 2, 7),
(27, 2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
CREATE TABLE IF NOT EXISTS `leaves` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`) VALUES
(1),
(3),
(6),
(9),
(10),
(12),
(19),
(22),
(23),
(25),
(27),
(28),
(30),
(31),
(33),
(35),
(39),
(40),
(43),
(48),
(50),
(51),
(52),
(53),
(54),
(56),
(57),
(58),
(59),
(61),
(63),
(64),
(67),
(68),
(69),
(70),
(72),
(74);

-- --------------------------------------------------------

--
-- Table structure for table `names`
--

DROP TABLE IF EXISTS `names`;
CREATE TABLE IF NOT EXISTS `names` (
  `id` int(11) NOT NULL,
  `property` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `name` text NOT NULL,
  UNIQUE KEY `id_2` (`id`,`priority`),
  KEY `id` (`id`),
  KEY `name` (`name`(64))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `names`
--

INSERT INTO `names` (`id`, `property`, `priority`, `name`) VALUES
(1, 38, 1, 'cubic meter'),
(3, 38, 1, 'ounce (oz)'),
(5, 38, 1, 'Event frequency'),
(6, 38, 1, 'kilogram per square meter'),
(7, 38, 1, 'base unit'),
(8, 38, 1, 'density unit'),
(9, 38, 1, 'mile (mi)'),
(10, 38, 1, 'hertz'),
(12, 38, 1, 'liter'),
(13, 38, 1, 'dimensionless unit'),
(14, 38, 1, 'US length unit'),
(15, 38, 1, 'frequency unit'),
(16, 38, 1, 'non-SI pressure unit'),
(17, 38, 1, 'volume flow unit'),
(18, 38, 1, 'kilogram'),
(19, 38, 1, 'millimeters of mercury'),
(21, 38, 1, 'Non-SI unit'),
(22, 38, 1, 'Events per minute'),
(23, 38, 1, 'liter per minute'),
(24, 38, 1, 'derived unit'),
(25, 38, 1, 'fraction'),
(26, 38, 1, 'length unit'),
(27, 38, 1, 'decibel'),
(28, 38, 1, 'pound (lb)'),
(29, 38, 1, 'time unit'),
(30, 38, 1, 'Events per week'),
(31, 38, 1, 'milligram'),
(32, 38, 1, 'mass unit'),
(33, 38, 1, 'yard (yd)'),
(34, 38, 1, 'US mass unit'),
(35, 38, 1, 'second'),
(36, 38, 1, 'area density unit'),
(37, 38, 1, 'ratio'),
(39, 38, 1, 'inch (in)'),
(40, 38, 1, 'year'),
(42, 38, 1, 'Metric system of measurement'),
(43, 38, 1, 'gram'),
(45, 38, 1, 'English system of measurement'),
(47, 38, 1, 'volume unit'),
(48, 38, 1, 'foot (ft)'),
(49, 38, 1, 'pressure unit'),
(50, 38, 1, 'event count'),
(51, 38, 1, 'percent'),
(52, 38, 1, 'day'),
(53, 38, 1, 'minute'),
(54, 38, 1, 'Events per month'),
(56, 38, 1, 'kilogram'),
(57, 38, 1, 'hour'),
(58, 38, 1, 'pascal'),
(59, 38, 1, 'month'),
(60, 38, 1, 'Unit of measurement'),
(61, 38, 1, 'Events per hour'),
(63, 38, 1, 'centimeter'),
(64, 38, 1, 'millimeter'),
(65, 38, 1, 'SI system (le Système international d''unités)'),
(67, 38, 1, 'scale'),
(68, 38, 1, 'week'),
(69, 38, 1, 'Events per year'),
(70, 38, 1, 'Events per day'),
(71, 38, 1, 'United States customary units'),
(72, 38, 1, 'meter'),
(73, 38, 1, 'count'),
(74, 38, 1, 'Events per second');

-- --------------------------------------------------------

--
-- Table structure for table `object_ontology`
--

DROP TABLE IF EXISTS `object_ontology`;
CREATE TABLE IF NOT EXISTS `object_ontology` (
  `object_id` int(11) NOT NULL,
  `ontology_id` int(11) NOT NULL,
  KEY `object_id` (`object_id`),
  KEY `ontology_id` (`ontology_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `object_ontology`
--

INSERT INTO `object_ontology` (`object_id`, `ontology_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ontologies`
--

DROP TABLE IF EXISTS `ontologies`;
CREATE TABLE IF NOT EXISTS `ontologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ontology_iri` text NOT NULL,
  `version_iri` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ontologies`
--

INSERT INTO `ontologies` (`id`, `ontology_iri`, `version_iri`) VALUES
(1, 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology', '');

-- --------------------------------------------------------

--
-- Table structure for table `owl_objects`
--

DROP TABLE IF EXISTS `owl_objects`;
CREATE TABLE IF NOT EXISTS `owl_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `iri` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `iri` (`iri`(256))
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `owl_objects`
--

INSERT INTO `owl_objects` (`id`, `type`, `iri`) VALUES
(1, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#cubic_meter'),
(2, 'Class', 'http://www.w3.org/2002/07/owl#Thing'),
(3, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#US_ounce'),
(4, 'AnnotationProperty', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#formula'),
(5, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#event_frequency'),
(6, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#kilogram_per_square_meter'),
(7, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#base_unit'),
(8, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#density_unit'),
(9, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#mile'),
(10, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#hertz'),
(11, 'AnnotationProperty', 'http://www.w3.org/2004/02/skos/core#altLabel'),
(12, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#liter'),
(13, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#dimensionless_unit'),
(14, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#US_length_unit'),
(15, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#frequency_unit'),
(16, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#non-SI_pressure_unit'),
(17, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#volume_flow_unit'),
(18, 'NamedIndividual', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#kilogram'),
(19, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#millimeters_of_mercury'),
(20, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#named_ratio'),
(21, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#Non-SI_unit'),
(22, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_minute'),
(23, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#liter_per_minute'),
(24, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#derived_unit'),
(25, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#fraction'),
(26, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#length_unit'),
(27, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#decibel'),
(28, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#US_pound'),
(29, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#time_unit'),
(30, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_week'),
(31, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#milligram'),
(32, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#mass_unit'),
(33, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#yard'),
(34, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#US_mass_unit'),
(35, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#second'),
(36, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#area_density_unit'),
(37, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#ratio'),
(38, 'AnnotationProperty', 'http://www.w3.org/2000/01/rdf-schema#label'),
(39, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#inch'),
(40, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#year'),
(41, 'AnnotationProperty', 'http://purl.org/dc/elements/1.1/creator'),
(42, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#metric_system'),
(43, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#gram'),
(44, 'AnnotationProperty', 'http://www.w3.org/2002/07/owl#versionInfo'),
(45, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#english_system'),
(46, 'AnnotationProperty', 'http://www.w3.org/2000/01/rdf-schema#comment'),
(47, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#volume_unit'),
(48, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#foot'),
(49, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#pressure_unit'),
(50, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#event_count'),
(51, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#percent'),
(52, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#day'),
(53, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#minute'),
(54, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_month'),
(55, 'Datatype', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#PlainLiteral'),
(56, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#kilogram'),
(57, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#hour'),
(58, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#pascal'),
(59, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#month'),
(60, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#unit'),
(61, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_hour'),
(62, 'AnnotationProperty', 'http://www.w3.org/2004/02/skos/core#prefLabel'),
(63, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#centimeter'),
(64, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#millimeter'),
(65, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#SI_system'),
(66, 'AnnotationProperty', 'http://purl.org/dc/elements/1.1/source'),
(67, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#scale'),
(68, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#week'),
(69, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_year'),
(70, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_day'),
(71, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#united_states_customary_units'),
(72, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#meter'),
(73, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#count'),
(74, 'Class', 'http://mimi.case.edu/ontologies/2009/1/UnitsOntology#events_per_second');

-- --------------------------------------------------------

--
-- Table structure for table `_extractors`
--

DROP TABLE IF EXISTS `_extractors`;
CREATE TABLE IF NOT EXISTS `_extractors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json` text,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `_extractors`
--

INSERT INTO `_extractors` (`id`, `json`, `last_updated`) VALUES
(1, '{"class":"pt.owlsql.extractors.SQLCoreUtils"}', '2016-03-17 19:10:43'),
(2, '{"class":"pt.owlsql.extractors.NamesExtractor","properties":["http://www.w3.org/2000/01/rdf-schema#label"]}', '2016-03-17 19:11:23'),
(3, '{"class":"pt.owlsql.extractors.HierarchyExtractor"}', '2016-03-17 19:11:53'),
(4, '{"class":"pt.owlsql.extractors.LeavesExtractor"}', '2016-03-17 19:11:53');

-- --------------------------------------------------------

--
-- Table structure for table `_extractors_realtime`
--

DROP TABLE IF EXISTS `_extractors_realtime`;
CREATE TABLE IF NOT EXISTS `_extractors_realtime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json` text,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `_ontologies`
--

DROP TABLE IF EXISTS `_ontologies`;
CREATE TABLE IF NOT EXISTS `_ontologies` (
  `uri` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_ontologies`
--

INSERT INTO `_ontologies` (`uri`) VALUES
('http://192.168.86.144/ontologies/onto_sdon.owl');

-- --------------------------------------------------------

--
-- Table structure for table `_owlsql`
--

DROP TABLE IF EXISTS `_owlsql`;
CREATE TABLE IF NOT EXISTS `_owlsql` (
  `last_execution` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_owlsql`
--

INSERT INTO `_owlsql` (`last_execution`) VALUES
('2016-03-17 19:10:08');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
